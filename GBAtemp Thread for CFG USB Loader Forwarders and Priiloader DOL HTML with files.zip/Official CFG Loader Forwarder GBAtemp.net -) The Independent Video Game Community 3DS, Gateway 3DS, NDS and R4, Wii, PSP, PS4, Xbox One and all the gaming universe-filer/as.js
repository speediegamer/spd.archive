var _____WB$wombat$assign$function_____ = function(name) {return (self._wb_wombat && self._wb_wombat.local_init && self._wb_wombat.local_init(name)) || self[name]; };
if (!self.__WB_pmw) { self.__WB_pmw = function(obj) { this.__WB_source = obj; return this; } }
{
  let window = _____WB$wombat$assign$function_____("window");
  let self = _____WB$wombat$assign$function_____("self");
  let document = _____WB$wombat$assign$function_____("document");
  let location = _____WB$wombat$assign$function_____("location");
  let top = _____WB$wombat$assign$function_____("top");
  let parent = _____WB$wombat$assign$function_____("parent");
  let frames = _____WB$wombat$assign$function_____("frames");
  let opener = _____WB$wombat$assign$function_____("opener");

/**
 * Simple xenForo editor AutoSave
 * Supports WYSIWYG editor and text box editor
 * Requires storage support in browser
 * Author: Adam Oest
 * Version: 0.1
 */
try
{
	var WYSIWYG_EDITOR = 'ctrl_message_html';
	var TEXTAREA_EDITOR = 'ctrl_message';
	var DEBUG = false;

	if (window.localStorage || localStorage) 
	{
		// Returns whether or not given data is "empty"
		function isEmpty(data)
		{
			return (
				data == '' 
				|| data.replace(' ','').length == 0
			);
		}

		// Replaces contents of editor with data
		function writeToEditor()
		{
			if (typeof tinyMCE != 'undefined')
			{
				tinyMCE.execInstanceCommand(WYSIWYG_EDITOR,'mceInsertContent',false,storage.getItem(storageKey));
			}
			else
			{
				$('#' + TEXTAREA_EDITOR).val(storage.getItem(storageKey));
			}
			
			if (DEBUG)
			{
				console.log('AutoSave :: Auto-fetched from storage ' + storageKey);
			}
		}

		// Clears stored data
		function clearStorage()
		{
			storage.removeItem(storageKey);
			
			if (DEBUG)
			{
				console.log('AutoSave :: Cleared cache for ' + storageKey);
			}
		}
	
		// Sets stored data
		function setStorage()
		{
			var data = getData();
			if (!isEmpty(data))
			{
				storage.setItem(storageKey, data);
			}
			else
			{
				clearStorage();
			}
		}

		// Gets text currently in the editor
		function getData()
		{	
			if (typeof tinyMCE != 'undefined')
			{
				return tinyMCE.get(WYSIWYG_EDITOR).getContent();
			}
			else
			{
				return $('#' + TEXTAREA_EDITOR).val();
			}
		}
	
		// Restores text into the editors / registers event handlers
		function insertData()
		{
			if (storage.getItem(storageKey) && isEmpty(getData()))
			{
				writeToEditor();
			}

			if (typeof tinyMCE != 'undefined')
			{
				tinyMCE.get(WYSIWYG_EDITOR).onKeyUp.add(setStorage);
				$('#' + WYSIWYG_EDITOR).parents('form').submit(function(){clearStorage();});
			}
			else
			{
				$('#' + TEXTAREA_EDITOR).keyup(setStorage);
				$('#' + TEXTAREA_EDITOR).parents('form').submit(function(){clearStorage();});
			}	
		}
		
		/* MAIN SCRIPT */

		// Determine URL portion for use as key
		var storage = localStorage || window.localStorage;		
		try
		{
			var urllen = window.location.href.split('/');
			var dl = urllen[0].length + urllen[2].length + 2;
		}
		catch (error)
		{
			var dl = 0;
		}

		var storageKey = window.location.href.slice(dl);
		if (storageKey.indexOf('#') != -1)
		{
			storageKey = storageKey.slice(0, storageKey.indexOf('#'));
		}
		
		// Main exec
		$(document).ready(function(){
			if (typeof tinyMCE != 'undefined')
			{
				tinyMCE.onAddEditor.add(function(mgr,ed){
					tinyMCE.get(ed.id).onInit.add(function(){					
						insertData();
					});
				});
			}
			else
			{
				insertData();
			}
		});
	}
}
catch (err) 
{ 
	console.log('AutoSave :: Error ' + err);
}


}
/*
     FILE ARCHIVED ON 03:01:45 Aug 20, 2014 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 15:29:02 Mar 06, 2021.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  exclusion.robots.policy: 0.262
  LoadShardBlock: 1194.759 (3)
  captures_list: 1258.796
  RedisCDXSource: 1.118
  CDXLines.iter: 28.025 (3)
  PetaboxLoader3.resolve: 1221.594 (3)
  esindex: 0.02
  PetaboxLoader3.datanode: 205.386 (5)
  exclusion.robots: 0.281
  load_resource: 316.25 (2)
*/